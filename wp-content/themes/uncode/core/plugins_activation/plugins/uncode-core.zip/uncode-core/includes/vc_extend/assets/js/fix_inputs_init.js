!function($) {
    "use strict";

    window.fixallInputs();
    window.uncode_hide_flip_from_hor_el();
	window.uncode_hide_animation_seq_from_css_grid();

}(window.jQuery);
